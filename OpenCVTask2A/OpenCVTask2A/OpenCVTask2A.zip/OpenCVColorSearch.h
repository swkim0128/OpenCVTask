#pragma once

#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "SerialPort.h"
using namespace std;
using namespace cv;

class OpenCVColorSearch {
private:
	char port_name[20] = "\\\\.\\COM3";

	SerialPort arduino;
public:	
	OpenCVColorSearch();

	void searchColor();
};