#include "OpenCVColorSearch.h"

OpenCVColorSearch::OpenCVColorSearch() : arduino(port_name) {
	if (arduino.isConnected())
		cout << "Connection Established" << endl;
	else
		cout << "ERROR, check port name" << endl;
}

void OpenCVColorSearch::searchColor() {
	char ch;

	while (arduino.isConnected())
	{
		if (_kbhit() == true)
		{
			VideoCapture capture(0);

			if (capture.isOpened() == false) {
				std::cerr << "Error, can not find capture divice\n";
				return;
			}

			while (1) {
				Mat frame;

				capture >> frame;

				if (frame.empty() == true)
					break;

				Mat hsv;
				cvtColor(frame, hsv, COLOR_RGB2HSV);

				int rowsMiddle = hsv.rows / 2;
				int colsMiddle = hsv.cols / 2;

				uchar h = (uchar)hsv.at<Vec3b>(rowsMiddle, colsMiddle)[0];
				uchar s = (uchar)hsv.at<Vec3b>(rowsMiddle, colsMiddle)[1];
				uchar v = (uchar)hsv.at<Vec3b>(rowsMiddle, colsMiddle)[2];

				if (0 < h && h < 10 && 100 < s && s < 255 && 100 < v && v < 255) {
					ch = 's';
				}
				else if (110 < h && h < 130 && 100 < s && s < 255 && 100 < v && v < 255) {
					ch = 'f';
				}
				else if (50 < h && h < 70 && 100 < s && s < 255 && 100 < v && v < 255) {
					ch = 'r';
				}
				else if (20 < h && h < 40 && 100 < s && s < 255 && 100 < v && v < 255) {
					ch = 'l';
				}
			}

			arduino.writeSerialPort(&ch, 1);
			cout << "Send: " << ch << endl;
		}
	}
}
